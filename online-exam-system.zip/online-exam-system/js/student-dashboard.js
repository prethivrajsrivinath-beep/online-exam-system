/* Student dashboard */
(function () {
  const me = DB.requireStudent(); if (!me) return;
  const { $, $$, esc, icon } = UI;
  UI.initTheme();
  const state = { view: 'overview', examQ: '', resQ: '' };
  const TITLES = { overview: 'Overview', exams: 'Exams', results: 'Results & history', profile: 'My profile' };
  const NAV = [['overview', 'Overview', 'home'], ['exams', 'Exams', 'book'], ['results', 'Results', 'file'], ['profile', 'Profile', 'user']];
  let renderBell = () => {};

  function shell() {
    $('#app').innerHTML = `
    <div class="app">
      <aside class="sidebar" id="sidebar">
        <a class="brand" href="dashboard.html"><span class="brand-mark">${icon('check', 20)}</span>ExamDesk</a>
        <nav class="nav">${NAV.map(n => `<a href="#${n[0]}" data-view="${n[0]}">${icon(n[2])}${n[1]}</a>`).join('')}</nav>
        <div class="side-user"><div class="avatar">${esc(UI.initials(me.name))}</div><div><strong id="sideName">${esc(me.name)}</strong><span>${esc(me.regNo)}</span></div></div>
        <div class="nav"><button id="logoutBtn">${icon('logout')}Logout</button></div>
      </aside>
      <div class="scrim" id="scrim"></div>
      <div class="main">
        <header class="topbar">
          <button class="btn-icon menu-btn" id="menuBtn" aria-label="Open menu">${icon('menu')}</button>
          <h1 id="pageTitle"></h1>
          <button class="btn-icon" data-theme-toggle aria-label="Toggle theme"></button>
          <div class="notif"><button class="btn-icon" id="bell" aria-label="Notifications">${icon('bell')}<span class="dot" id="bellDot" hidden></span></button><div class="notif-panel" id="notifPanel" hidden></div></div>
        </header>
        <main class="content" id="view"></main>
      </div>
    </div>`;
    UI.syncThemeIcons();
    renderBell = UI.initNotifications(me.id);
    $('#menuBtn').onclick = () => toggleMenu(true);
    $('#scrim').onclick = () => toggleMenu(false);
    $('#logoutBtn').onclick = async () => {
      if (DB.getAttempt(me.id)) { UI.toast('You have an exam in progress. Finish it before logging out.', 'warn'); return; }
      if (await UI.confirm({ title: 'Log out?', message: 'You will need to log in again to see your dashboard.', confirmText: 'Logout' })) { DB.logoutStudent(); location.href = 'login.html'; }
    };
    $$('[data-view]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); go(a.dataset.view); toggleMenu(false); }));
  }
  function toggleMenu(open) { $('#sidebar').classList.toggle('open', open); $('#scrim').classList.toggle('show', open); }

  function go(view) {
    state.view = view; history.replaceState(null, '', '#' + view);
    $$('[data-view]').forEach(a => a.classList.toggle('active', a.dataset.view === view));
    $('#pageTitle').textContent = TITLES[view];
    ({ overview, exams, results, profile })[view]();
    window.scrollTo(0, 0);
  }

  /* ---------- helpers ---------- */
  const myResults = () => DB.resultsFor(me.id);
  const startable = e => e.questions.length > 0;
  const openExams = () => DB.getExams().filter(e => DB.examPhase(e) === 'open' && startable(e));
  const upcomingExams = () => DB.getExams().filter(e => DB.examPhase(e) === 'upcoming');
  const statusBadge = r => r.passed ? '<span class="badge good">Pass</span>' : '<span class="badge bad">Fail</span>';

  function examCard(e, phase) {
    const mine = myResults().filter(r => r.examId === e.id);
    const best = mine.length ? Math.max(...mine.map(r => r.percentage)) : null;
    const attempt = DB.getAttempt(me.id); const resume = attempt && attempt.examId === e.id;
    const foot = phase === 'upcoming'
      ? `<span class="badge warn">${icon('clock', 13)} Opens ${UI.fmtDateTime(e.startDate)}</span><button class="btn btn-ghost btn-sm" disabled>Not open yet</button>`
      : `<span class="muted small">${best == null ? 'Not attempted yet' : `Attempts: ${mine.length} · Best: ${UI.pct(best)}`}</span>
         <button class="btn btn-primary" data-start="${e.id}">${resume ? 'Resume exam' : 'Start exam'}</button>`;
    return `<article class="exam-card ${phase}">
      <div><h4>${esc(e.title)}</h4><span class="badge primary">${esc(e.subject)}</span></div>
      <div class="meta"><span>${icon('help', 14)} ${e.questions.length} questions</span><span>${icon('clock', 14)} ${e.duration} min</span><span>${icon('award', 14)} ${e.totalMarks} marks</span></div>
      <div class="foot">${foot}</div></article>`;
  }
  function matches(e, q) { q = q.trim().toLowerCase(); return !q || (e.title + ' ' + e.subject).toLowerCase().includes(q); }

  document.addEventListener('click', e => {
    const b = e.target.closest('[data-start]'); if (!b) return;
    const id = b.dataset.start, attempt = DB.getAttempt(me.id);
    if (attempt && attempt.examId !== id) { UI.toast('You already have an exam in progress. Resume it first.', 'warn'); location.href = 'exam.html?exam=' + attempt.examId; return; }
    const ex = DB.getExam(id);
    if (!ex || DB.examPhase(ex) !== 'open') { UI.toast('This exam is not available right now.', 'error'); return go('exams'); }
    location.href = attempt ? 'exam.html?exam=' + id : 'instructions.html?exam=' + id;
  });
  document.addEventListener('click', e => { const b = e.target.closest('[data-goto]'); if (b) go(b.dataset.goto); });

  /* ---------- overview ---------- */
  function overview() {
    const rs = myResults(), avail = openExams();
    const avg = rs.length ? rs.reduce((s, r) => s + r.percentage, 0) / rs.length : 0;
    const best = rs.length ? Math.max(...rs.map(r => r.percentage)) : 0;
    const passRate = rs.length ? rs.filter(r => r.passed).length / rs.length * 100 : 0;
    const attempt = DB.getAttempt(me.id);
    const hour = new Date().getHours(), greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>${greet}, ${esc(me.name.split(' ')[0])}</h2><p class="muted">${avail.length ? `${avail.length} exam${avail.length > 1 ? 's are' : ' is'} ready for you.` : 'No exams are open right now.'}</p></div></div>
      ${attempt ? `<div class="banner"><div><strong>Exam in progress:</strong> ${esc(attempt.exam.title)}. Your answers are saved.</div><a class="btn btn-primary" href="exam.html?exam=${attempt.examId}">Resume exam</a></div>` : ''}
      <div class="grid stats">
        <div class="card stat"><div class="chip">${icon('file', 22)}</div><div><b>${rs.length}</b><span>Exams taken</span></div></div>
        <div class="card stat"><div class="chip warn">${icon('activity', 22)}</div><div><b>${rs.length ? UI.pct(avg) : '—'}</b><span>Average score</span></div></div>
        <div class="card stat"><div class="chip good">${icon('award', 22)}</div><div><b>${rs.length ? UI.pct(best) : '—'}</b><span>Best score</span></div></div>
        <div class="card stat"><div class="chip ${passRate >= 50 || !rs.length ? 'good' : 'bad'}">${icon('check', 22)}</div><div><b>${rs.length ? Math.round(passRate) + '%' : '—'}</b><span>Pass rate</span></div></div>
      </div>
      <div class="grid split">
        <div class="card"><div class="card-head"><h3>Recent performance</h3><span class="muted small">Last ${Math.min(8, rs.length)} exams</span></div>${UI.trend(rs)}</div>
        <div class="card"><div class="card-head"><h3>Available now</h3><button class="link" data-goto="exams">See all</button></div>
          ${avail.length ? avail.slice(0, 3).map(e => `<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--line)"><div><strong>${esc(e.title)}</strong><div class="muted small">${e.questions.length} questions · ${e.duration} min</div></div><button class="btn btn-soft btn-sm" data-start="${e.id}">Start</button></div>`).join('') : '<div class="empty small">Nothing is open yet. Check back soon.</div>'}
        </div>
      </div>
      <div class="card flush" style="margin-top:18px"><div class="card-head" style="padding:20px 22px 0"><h3>Latest results</h3><button class="link" data-goto="results">Full history</button></div>${resultsTable(rs.slice(0, 4), false)}</div>`;
  }

  /* ---------- exams ---------- */
  function exams() {
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>Exams</h2><p class="muted">Only exams published by your admin appear here.</p></div>
        <div class="search">${icon('search', 16)}<input id="examSearch" type="search" placeholder="Search by title or subject" value="${esc(state.examQ)}"></div></div>
      <div id="examBox"></div>`;
    const draw = () => {
      const o = openExams().filter(e => matches(e, state.examQ)), u = upcomingExams().filter(e => matches(e, state.examQ));
      $('#examBox').innerHTML = `
        <h3 class="section-title">Available exams <span class="badge primary">${o.length}</span></h3>
        ${o.length ? `<div class="grid cards">${o.map(e => examCard(e, 'open')).join('')}</div>` : `<div class="card empty"><strong>${state.examQ ? 'No exams match your search' : 'No exams are open right now'}</strong>${state.examQ ? 'Try a different word.' : 'When your admin publishes an exam, it will show up here.'}</div>`}
        <h3 class="section-title">Upcoming exams <span class="badge warn">${u.length}</span></h3>
        ${u.length ? `<div class="grid cards">${u.map(e => examCard(e, 'upcoming')).join('')}</div>` : '<div class="card empty small"><strong>No upcoming exams</strong>Scheduled exams will be listed here with their opening time.</div>'}`;
    };
    draw();
    $('#examSearch').addEventListener('input', UI.debounce(e => { state.examQ = e.target.value; draw(); }));
  }

  /* ---------- results ---------- */
  function resultsTable(rs, withView) {
    if (!rs.length) return '<div class="empty"><strong>No results yet</strong>Finish an exam and your score will appear here.</div>';
    return `<div class="table-wrap"><table><thead><tr><th>Exam</th><th>Date</th><th>Score</th><th>Percentage</th><th>Status</th><th></th></tr></thead><tbody>
      ${rs.map(r => `<tr><td><strong>${esc(r.examTitle)}</strong><span class="sub">${esc(r.subject)}</span></td><td>${UI.fmtDateTime(r.date)}</td>
      <td>${r.marks} / ${r.totalMarks}<span class="sub">${r.correct}/${r.total} correct</span></td><td><strong>${UI.pct(r.percentage)}</strong></td><td>${statusBadge(r)}</td>
      <td class="right"><a class="btn btn-ghost btn-sm" href="result.html?id=${r.id}">${icon('eye', 14)} View</a></td></tr>`).join('')}</tbody></table></div>`;
  }
  function results() {
    const all = myResults();
    const bySubject = {};
    all.forEach(r => { (bySubject[r.subject] = bySubject[r.subject] || []).push(r.percentage); });
    const subj = Object.entries(bySubject).map(([k, v]) => ({ label: k, value: v.reduce((a, b) => a + b, 0) / v.length, text: Math.round(v.reduce((a, b) => a + b, 0) / v.length) + '%' }));
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>Results & exam history</h2><p class="muted">Every exam you have submitted, newest first.</p></div>
        <div class="search">${icon('search', 16)}<input id="resSearch" type="search" placeholder="Search exam or subject" value="${esc(state.resQ)}"></div></div>
      <div class="grid split" style="margin-bottom:18px">
        <div class="card flush"><div id="resBox"></div></div>
        <div class="card"><div class="card-head"><h3>Average by subject</h3></div>${UI.bars(subj)}</div>
      </div>`;
    const draw = () => {
      const q = state.resQ.trim().toLowerCase();
      const list = all.filter(r => !q || (r.examTitle + ' ' + r.subject).toLowerCase().includes(q));
      $('#resBox').innerHTML = list.length || !all.length ? resultsTable(list, true) : '<div class="empty"><strong>No results match your search</strong>Try a different word.</div>';
    };
    draw();
    $('#resSearch').addEventListener('input', UI.debounce(e => { state.resQ = e.target.value; draw(); }));
  }

  /* ---------- profile ---------- */
  function profile() {
    const s = DB.getStudent(me.id), rs = myResults();
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>My profile</h2><p class="muted">Your details as registered with ExamDesk.</p></div></div>
      <div class="grid two">
        <div class="card stack" style="gap:18px">
          <div class="profile-head"><div class="avatar lg">${esc(UI.initials(s.name))}</div><div><h3 style="margin:0">${esc(s.name)}</h3><span class="badge primary">${esc(s.regNo)}</span></div></div>
          <dl class="kv"><dt>Email ID</dt><dd>${esc(s.email)}</dd><dt>Mobile number</dt><dd>${esc(s.mobile)}</dd><dt>Register number</dt><dd>${esc(s.regNo)}</dd>
            <dt>Registered on</dt><dd>${UI.fmtDate(s.createdAt)}</dd><dt>Exams taken</dt><dd>${rs.length}</dd></dl>
        </div>
        <div class="stack">
          <form class="card" id="editForm" novalidate><h3>Edit details</h3>
            <div class="field"><label for="pn">Student name</label><input id="pn" name="name" value="${esc(s.name)}"><span class="err"></span></div>
            <div class="field"><label for="pm">Mobile number</label><input id="pm" name="mobile" value="${esc(s.mobile)}" maxlength="10" inputmode="numeric"><span class="err"></span></div>
            <button class="btn btn-primary" type="submit">Save changes</button></form>
          <form class="card" id="pwForm" novalidate><h3>Change password</h3>
            <div class="field"><label for="op">Current password</label><input id="op" name="old" type="password" autocomplete="current-password"><span class="err"></span></div>
            <div class="row2"><div class="field"><label for="np">New password</label><input id="np" name="pw" type="password" autocomplete="new-password"><span class="err"></span></div>
            <div class="field"><label for="cp">Confirm new password</label><input id="cp" name="cf" type="password" autocomplete="new-password"><span class="err"></span></div></div>
            <button class="btn btn-primary" type="submit">Update password</button></form>
        </div>
      </div>`;
    $('#editForm').addEventListener('submit', e => {
      e.preventDefault(); const f = e.target.elements; let ok = true;
      const nameOk = /^[A-Za-z][A-Za-z .'-]{2,49}$/.test(f.name.value.trim()); UI.setErr(f.name, nameOk ? '' : 'Enter your full name (letters only, at least 3 characters).');
      const mobOk = /^[6-9]\d{9}$/.test(f.mobile.value.trim()); UI.setErr(f.mobile, mobOk ? '' : 'Enter a 10-digit mobile number starting with 6, 7, 8 or 9.');
      if (!nameOk || !mobOk) return;
      DB.updateStudent(me.id, { name: f.name.value.trim(), mobile: f.mobile.value.trim() });
      me.name = f.name.value.trim(); $('#sideName').textContent = me.name; UI.toast('Profile updated.', 'success'); profile();
    });
    $('#pwForm').addEventListener('submit', e => {
      e.preventDefault(); const f = e.target.elements;
      const pwOk = f.pw.value.length >= 6 && /[A-Za-z]/.test(f.pw.value) && /\d/.test(f.pw.value);
      UI.setErr(f.old, f.old.value ? '' : 'Enter your current password.');
      UI.setErr(f.pw, pwOk ? '' : 'Use at least 6 characters with a letter and a number.');
      UI.setErr(f.cf, f.cf.value === f.pw.value ? '' : 'Passwords do not match.');
      if (!f.old.value || !pwOk || f.cf.value !== f.pw.value) return;
      const r = DB.changeStudentPassword(me.id, f.old.value, f.pw.value);
      if (!r.ok) return UI.setErr(f.old, r.error);
      UI.toast('Password updated.', 'success'); e.target.reset();
    });
  }

  shell();
  const flash = sessionStorage.getItem('ex_flash'); if (flash) { sessionStorage.removeItem('ex_flash'); UI.toast(flash, 'warn'); }
  const start = (location.hash || '#overview').slice(1);
  go(TITLES[start] ? start : 'overview');
  // pick up notifications & phase changes while the page stays open
  setInterval(() => renderBell(), 30000);
  window.addEventListener('storage', () => renderBell());
})();
