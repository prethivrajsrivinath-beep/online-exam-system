/* Exam instructions page */
(function () {
  const me = DB.requireStudent(); if (!me) return;
  const { $, esc, icon } = UI; UI.initTheme();
  const id = new URLSearchParams(location.search).get('exam');
  const e = DB.getExam(id);
  const active = DB.getAttempt(me.id);
  if (active) { location.replace('exam.html?exam=' + active.examId); return; }

  const bad = msg => {
    $('#app').innerHTML = `<div class="narrow"><div class="card empty"><strong>${esc(msg)}</strong><p>Head back to the dashboard to pick another exam.</p><a class="btn btn-primary" href="dashboard.html#exams">Back to exams</a></div></div>`;
  };
  if (!e || DB.examPhase(e) !== 'open') return bad('This exam is not available right now.');
  if (!e.questions.length) return bad('This exam has no questions yet.');

  const per = e.totalMarks / e.questions.length;
  $('#app').innerHTML = `
    <div class="plain-top"><a class="brand" href="dashboard.html"><span class="brand-mark">${icon('check', 20)}</span>ExamDesk</a>
      <button class="btn-icon" data-theme-toggle aria-label="Toggle theme"></button></div>
    <div class="narrow">
      <a class="link" href="dashboard.html#exams">${icon('back', 14)} Back to exams</a>
      <div class="card" style="margin-top:14px">
        <span class="badge primary">${esc(e.subject)}</span>
        <h2 style="margin-top:10px">${esc(e.title)}</h2>
        ${e.instructions ? `<p class="muted">${esc(e.instructions)}</p>` : ''}
        <div class="info-tiles">
          <div class="tile"><b>${e.questions.length}</b><span>Questions</span></div>
          <div class="tile"><b>${e.duration} min</b><span>Time allowed</span></div>
          <div class="tile"><b>${e.totalMarks}</b><span>Total marks</span></div>
          <div class="tile"><b>${e.passPercent}%</b><span>To pass</span></div>
        </div>
        <h3>Before you start</h3>
        <ul class="rules">
          <li>Each question has four options and only one is correct. Every question carries ${+per.toFixed(2)} mark${per === 1 ? '' : 's'}.</li>
          <li>There is no negative marking. Unanswered questions score zero.</li>
          <li>The timer starts when you press <b>Start exam</b> and keeps running even if you close the tab.</li>
          <li>Your selected answers are saved automatically. Use the question numbers to jump around or <b>Mark for review</b> to flag a question.</li>
          <li>You will get a warning when 5 minutes remain. When the time ends, the exam is submitted automatically.</li>
          <li>Refreshing the page is blocked during the exam. Do not switch away for long.</li>
          ${e.shuffleQuestions || e.shuffleOptions ? `<li>${[e.shuffleQuestions && 'Questions', e.shuffleOptions && 'answer options'].filter(Boolean).join(' and ')} appear in a random order for each attempt.</li>` : ''}
        </ul>
        <label class="check"><input type="checkbox" id="agree"> I have read the instructions and I am ready to begin.</label>
        <div class="modal-actions" style="justify-content:flex-start">
          <button class="btn btn-primary" id="startBtn" disabled>Start exam</button>
          <a class="btn btn-ghost" href="dashboard.html#exams">Cancel</a>
        </div>
      </div>
    </div>`;
  UI.syncThemeIcons();
  $('#agree').addEventListener('change', ev => { $('#startBtn').disabled = !ev.target.checked; });
  $('#startBtn').addEventListener('click', () => {
    sessionStorage.setItem('ex_ack_' + me.id + '_' + e.id, '1');
    location.href = 'exam.html?exam=' + e.id;
  });
})();
