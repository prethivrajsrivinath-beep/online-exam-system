/* Admin portal: overview, exam papers, questions, students, results, activity, settings */
(function () {
  const admin = DB.requireAdmin(); if (!admin) return;
  const { $, $$, esc, icon } = UI; UI.initTheme();
  const state = { view: 'overview', examId: null, q: { exams: '', students: '', results: '' }, status: 'all' };
  const NAV = [['overview', 'Overview', 'grid'], ['exams', 'Exam papers', 'book'], ['students', 'Students', 'users'], ['results', 'Results', 'file'], ['activity', 'Activity', 'activity'], ['settings', 'Settings', 'settings']];
  const TITLES = { overview: 'Dashboard overview', exams: 'Exam papers', questions: 'Manage questions', students: 'Students', results: 'Results', activity: 'Admin activity', settings: 'Settings' };
  let renderBell = () => {};

  /* ---------- shell ---------- */
  function shell() {
    $('#app').innerHTML = `
    <div class="app">
      <aside class="sidebar" id="sidebar">
        <a class="brand" href="dashboard.html"><span class="brand-mark">${icon('shield', 20)}</span>ExamDesk Admin</a>
        <nav class="nav">${NAV.map(n => `<a href="#${n[0]}" data-view="${n[0]}">${icon(n[2])}${n[1]}</a>`).join('')}</nav>
        <div class="side-user"><div class="avatar">${esc(UI.initials(admin.username))}</div><div><strong>${esc(admin.username)}</strong><span>Administrator</span></div></div>
        <div class="nav"><button id="logoutBtn">${icon('logout')}Logout</button></div>
      </aside>
      <div class="scrim" id="scrim"></div>
      <div class="main">
        <header class="topbar">
          <button class="btn-icon menu-btn" id="menuBtn" aria-label="Open menu">${icon('menu')}</button>
          <h1 id="pageTitle"></h1>
          <button class="btn-icon" data-theme-toggle aria-label="Toggle theme"></button>
          <div class="notif"><button class="btn-icon" id="bell" aria-label="Notifications">${icon('bell')}<span class="dot" id="bellDot" hidden></span></button><div class="notif-panel" id="notifPanel" hidden></div></div>
        </header>
        <main class="content" id="view"></main>
      </div>
    </div>`;
    UI.syncThemeIcons();
    renderBell = UI.initNotifications('admin');
    $('#menuBtn').onclick = () => menu(true); $('#scrim').onclick = () => menu(false);
    $('#logoutBtn').onclick = async () => {
      if (await UI.confirm({ title: 'Log out of the admin panel?', message: 'You will need your username and password to get back in.', confirmText: 'Logout' })) { DB.logoutAdmin(); location.href = 'login.html'; }
    };
    $$('[data-view]').forEach(a => a.addEventListener('click', e => { e.preventDefault(); go(a.dataset.view); menu(false); }));
  }
  const menu = open => { $('#sidebar').classList.toggle('open', open); $('#scrim').classList.toggle('show', open); };

  function go(view, examId) {
    state.view = view; if (examId) state.examId = examId;
    history.replaceState(null, '', '#' + (view === 'questions' ? 'exams' : view));
    $$('[data-view]').forEach(a => a.classList.toggle('active', a.dataset.view === (view === 'questions' ? 'exams' : view)));
    $('#pageTitle').textContent = TITLES[view];
    ({ overview, exams, questions, students, results, activity, settings })[view]();
    window.scrollTo(0, 0); renderBell();
  }

  /* ---------- shared bits ---------- */
  const phaseBadge = e => { const p = DB.examPhase(e); return p === 'draft' ? '<span class="badge muted">Draft</span>' : p === 'upcoming' ? '<span class="badge warn">Scheduled</span>' : '<span class="badge good">Published</span>'; };
  const passBadge = r => r.passed ? '<span class="badge good">Pass</span>' : '<span class="badge bad">Fail</span>';
  const toLocalInput = iso => { if (!iso) return ''; const d = new Date(iso); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
  const searchBox = (id, ph, val) => `<div class="search">${icon('search', 16)}<input id="${id}" type="search" placeholder="${ph}" value="${esc(val)}"></div>`;
  const stat = (chip, ic, val, label, extra) => `<div class="card stat"><div class="chip ${chip}">${icon(ic, 22)}</div><div><b>${val}</b><span>${label}</span>${extra ? `<span style="display:block;font-size:.78rem">${extra}</span>` : ''}</div></div>`;
  const hook = (id, key, draw) => { $('#' + id).addEventListener('input', UI.debounce(e => { state.q[key] = e.target.value; draw(); })); };

  /* ---------- overview ---------- */
  function overview() {
    const st = DB.getStudents(), ex = DB.getExams(), rs = DB.getResults();
    const qCount = ex.reduce((s, e) => s + e.questions.length, 0);
    const pub = ex.filter(e => e.published).length;
    const avg = rs.length ? rs.reduce((s, r) => s + r.percentage, 0) / rs.length : 0;
    const passRate = rs.length ? rs.filter(r => r.passed).length / rs.length * 100 : 0;
    const byExam = ex.map(e => { const l = rs.filter(r => r.examId === e.id); return l.length ? { label: e.title, value: l.reduce((s, r) => s + r.percentage, 0) / l.length, text: Math.round(l.reduce((s, r) => s + r.percentage, 0) / l.length) + '%' } : null; }).filter(Boolean);
    const act = DB.getActivity().slice(0, 7);
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>Welcome back, ${esc(admin.username)}</h2><p class="muted">Last sign-in: ${admin.previousLogin ? UI.fmtDateTime(admin.previousLogin) : 'this is your first sign-in'}</p></div>
        <button class="btn btn-primary" data-act="new-exam">${icon('plus')} Create exam</button></div>
      <div class="grid stats">
        ${stat('', 'users', st.length, 'Registered students')}
        ${stat('warn', 'book', ex.length, 'Total exams', `${pub} published · ${ex.length - pub} draft`)}
        ${stat('good', 'help', qCount, 'Total questions')}
        ${stat('bad', 'file', rs.length, 'Completed exams', rs.length ? `Average ${Math.round(avg)}% · ${Math.round(passRate)}% pass` : '')}
      </div>
      <div class="grid split">
        <div class="card flush"><div class="card-head" style="padding:20px 22px 0"><h3>Recent student results</h3><button class="link" data-go="results">View all</button></div>${resultsTable(rs.slice().sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5), false)}</div>
        <div class="card"><div class="card-head"><h3>Recent activity</h3><button class="link" data-go="activity">View all</button></div>
          ${act.length ? `<ul class="feed">${act.map(a => `<li><span class="dotmark"></span><div>${esc(a.text)}<time>${esc(a.actor)} · ${UI.timeAgo(a.time)}</time></div></li>`).join('')}</ul>` : '<div class="empty small">No activity yet.</div>'}</div>
      </div>
      <div class="card" style="margin-top:18px"><div class="card-head"><h3>Average score by exam</h3></div>${UI.bars(byExam)}</div>`;
  }

  /* ---------- exams ---------- */
  function exams() {
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>Exam papers</h2><p class="muted">Create papers, add questions, then publish them to students.</p></div>
        <button class="btn btn-primary" data-act="new-exam">${icon('plus')} Create exam</button></div>
      <div class="card flush"><div class="toolbar">${searchBox('examSearch', 'Search exams or subjects', state.q.exams)}</div><div id="box"></div></div>`;
    const draw = () => {
      const q = state.q.exams.trim().toLowerCase(), rs = DB.getResults();
      const list = DB.getExams().filter(e => !q || (e.title + ' ' + e.subject).toLowerCase().includes(q));
      $('#box').innerHTML = list.length ? `<div class="table-wrap"><table><thead><tr><th>Exam</th><th>Duration</th><th>Marks</th><th>Questions</th><th>Attempts</th><th>Status</th><th class="right">Actions</th></tr></thead><tbody>
        ${list.map(e => `<tr><td><strong>${esc(e.title)}</strong><span class="sub">${esc(e.subject)}${e.startDate ? ' · opens ' + UI.fmtDateTime(e.startDate) : ''}</span></td>
          <td>${e.duration} min</td><td>${e.totalMarks}<span class="sub">Pass ${e.passPercent}%</span></td><td>${e.questions.length}</td><td>${rs.filter(r => r.examId === e.id).length}</td><td>${phaseBadge(e)}</td>
          <td><div class="actions">
            <button class="btn btn-soft btn-sm" data-act="questions" data-id="${e.id}">${icon('help', 14)} Questions</button>
            <button class="btn-icon sm" title="Edit exam details" aria-label="Edit exam details" data-act="edit-exam" data-id="${e.id}">${icon('edit', 15)}</button>
            <button class="btn btn-ghost btn-sm" data-act="toggle-pub" data-id="${e.id}">${e.published ? 'Unpublish' : 'Publish'}</button>
            <button class="btn-icon sm danger" title="Delete exam" aria-label="Delete exam" data-act="del-exam" data-id="${e.id}">${icon('trash', 15)}</button></div></td></tr>`).join('')}</tbody></table></div>`
        : `<div class="empty"><strong>${q ? 'No exams match your search' : 'No exam papers yet'}</strong>${q ? 'Try a different word.' : 'Create your first exam to get started.'}</div>`;
    };
    draw(); hook('examSearch', 'exams', draw);
  }

  function examForm(e) {
    const isNew = !e; e = e || { title: '', subject: '', duration: 30, totalMarks: 20, passPercent: 40, startDate: '', instructions: '', shuffleQuestions: true, shuffleOptions: true };
    const m = UI.modal(`<h3>${isNew ? 'Create exam' : 'Update exam paper'}</h3>
      <p class="muted">${isNew ? 'Set up the basics. You will add questions next.' : 'Changes apply to new attempts only.'}</p>
      <form id="examForm" novalidate>
        <div class="row2"><div class="field"><label for="f-title">Exam name</label><input id="f-title" name="title" value="${esc(e.title)}" placeholder="e.g. Physics Unit Test"><span class="err"></span></div>
        <div class="field"><label for="f-subject">Subject</label><input id="f-subject" name="subject" value="${esc(e.subject)}" placeholder="e.g. Physics"><span class="err"></span></div></div>
        <div class="row3"><div class="field"><label for="f-dur">Duration (minutes)</label><input id="f-dur" name="duration" type="number" min="1" max="300" value="${e.duration}"><span class="err"></span></div>
        <div class="field"><label for="f-marks">Total marks</label><input id="f-marks" name="totalMarks" type="number" min="1" max="1000" value="${e.totalMarks}"><span class="err"></span></div>
        <div class="field"><label for="f-pass">Pass mark (%)</label><input id="f-pass" name="passPercent" type="number" min="0" max="100" value="${e.passPercent}"><span class="err"></span></div></div>
        <div class="field"><label for="f-start">Opens on (optional)</label><input id="f-start" name="startDate" type="datetime-local" value="${toLocalInput(e.startDate)}"><div class="hint">Leave empty to open as soon as it is published. A future date shows it as an upcoming exam.</div><span class="err"></span></div>
        <div class="field"><label for="f-ins">Instructions for students (optional)</label><textarea id="f-ins" name="instructions" placeholder="Shown on the instructions page">${esc(e.instructions)}</textarea></div>
        <label class="check"><input type="checkbox" name="shuffleQuestions" ${e.shuffleQuestions ? 'checked' : ''}> Random question order</label>
        <label class="check"><input type="checkbox" name="shuffleOptions" ${e.shuffleOptions ? 'checked' : ''}> Random option order</label>
        <div class="modal-actions"><button type="button" class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-primary" type="submit">${isNew ? 'Create exam' : 'Save changes'}</button></div>
      </form>`);
    $('#examForm', m.el).addEventListener('submit', ev => {
      ev.preventDefault(); const f = ev.target.elements; let ok = true;
      const chk = (inp, cond, msg) => { UI.setErr(inp, cond ? '' : msg); if (!cond) ok = false; };
      chk(f.title, f.title.value.trim().length >= 3, 'Enter an exam name (at least 3 characters).');
      chk(f.subject, f.subject.value.trim().length >= 2, 'Enter a subject.');
      chk(f.duration, +f.duration.value >= 1 && +f.duration.value <= 300, 'Duration must be 1–300 minutes.');
      chk(f.totalMarks, +f.totalMarks.value >= 1 && +f.totalMarks.value <= 1000, 'Total marks must be 1–1000.');
      chk(f.passPercent, f.passPercent.value !== '' && +f.passPercent.value >= 0 && +f.passPercent.value <= 100, 'Pass mark must be 0–100.');
      if (!ok) return;
      const exam = Object.assign({}, e, {
        id: isNew ? DB.newExamId() : e.id, title: f.title.value.trim(), subject: f.subject.value.trim(), duration: Math.round(+f.duration.value), totalMarks: +f.totalMarks.value,
        passPercent: +f.passPercent.value, startDate: f.startDate.value ? new Date(f.startDate.value).toISOString() : '', instructions: f.instructions.value.trim(),
        shuffleQuestions: f.shuffleQuestions.checked, shuffleOptions: f.shuffleOptions.checked
      });
      if (isNew) { exam.published = false; exam.questions = []; exam.createdAt = new Date().toISOString(); }
      DB.saveExam(exam); DB.logActivity(`${isNew ? 'Created' : 'Updated'} exam "${exam.title}"`);
      m.close();
      if (isNew) { UI.toast('Exam created. Now add its questions.', 'success'); go('questions', exam.id); }
      else { UI.toast('Exam updated.', 'success'); go(state.view === 'questions' ? 'questions' : 'exams', exam.id); }
    });
  }

  /* ---------- questions ---------- */
  function questions() {
    const e = DB.getExam(state.examId); if (!e) return go('exams');
    const per = e.questions.length ? (e.totalMarks / e.questions.length) : 0;
    $('#view').innerHTML = `
      <div class="page-head"><div><button class="link" data-go="exams" style="margin-bottom:8px">${icon('back', 14)} Back to exam papers</button>
        <h2>${esc(e.title)} ${phaseBadge(e)}</h2><p class="muted">${esc(e.subject)} · ${e.duration} min · ${e.totalMarks} marks · pass ${e.passPercent}% · ${e.questions.length} question${e.questions.length === 1 ? '' : 's'}${per ? ` (${+per.toFixed(2)} marks each)` : ''}</p></div>
        <div style="display:flex;gap:10px;flex-wrap:wrap">
          <button class="btn btn-ghost" data-act="edit-exam" data-id="${e.id}">${icon('edit', 16)} Edit details</button>
          <button class="btn btn-ghost" data-act="toggle-pub" data-id="${e.id}">${e.published ? 'Unpublish' : 'Publish'}</button>
          <button class="btn btn-primary" data-act="add-q">${icon('plus')} Add question</button></div></div>
      <div class="card flush">${e.questions.length ? e.questions.map((q, i) => `
        <article class="q-item"><div class="q-num">${i + 1}</div>
          <div class="q-body"><p class="q-text">${esc(q.text)}</p>
            <ul class="q-opts">${q.options.map((o, j) => `<li class="${j === q.correct ? 'correct' : ''}"><span>${'ABCD'[j]}</span>${esc(o)}${j === q.correct ? ' <em>· correct</em>' : ''}</li>`).join('')}</ul></div>
          <div class="q-actions"><button class="btn-icon sm" title="Edit question" aria-label="Edit question" data-act="edit-q" data-id="${q.id}">${icon('edit', 15)}</button>
            <button class="btn-icon sm danger" title="Delete question" aria-label="Delete question" data-act="del-q" data-id="${q.id}">${icon('trash', 15)}</button></div></article>`).join('')
        : `<div class="empty"><strong>No questions yet</strong>Add the first multiple-choice question for this exam.<br><br><button class="btn btn-primary" data-act="add-q">${icon('plus')} Add question</button></div>`}</div>`;
  }

  function questionForm(qid) {
    const e = DB.getExam(state.examId); const q = qid ? e.questions.find(x => x.id === qid) : null;
    const v = q || { text: '', options: ['', '', '', ''], correct: 0 };
    const m = UI.modal(`<h3>${q ? 'Edit question' : 'Add question'}</h3><p class="muted">Enter four options and choose the correct one.</p>
      <form id="qForm" novalidate>
        <div class="field"><label for="q-text">Question</label><textarea id="q-text" name="text" placeholder="Type the question here">${esc(v.text)}</textarea><span class="err"></span></div>
        ${[0, 1, 2, 3].map(i => `<div class="correct-pick"><input type="radio" name="correct" value="${i}" ${v.correct === i ? 'checked' : ''} aria-label="Mark option ${'ABCD'[i]} as correct">
          <div class="field"><input name="o${i}" value="${esc(v.options[i])}" placeholder="Option ${'ABCD'[i]}" aria-label="Option ${'ABCD'[i]}"><span class="err"></span></div></div>`).join('')}
        <div class="hint" style="margin-top:-4px">The selected radio button marks the correct answer.</div>
        <div class="modal-actions"><button type="button" class="btn btn-ghost" data-close>Cancel</button><button class="btn btn-primary" type="submit">${q ? 'Save question' : 'Add question'}</button></div>
      </form>`, { wide: true });
    $('#qForm', m.el).addEventListener('submit', ev => {
      ev.preventDefault(); const f = ev.target.elements; let ok = true;
      const text = f.text.value.trim(); UI.setErr(f.text, text.length >= 5 ? '' : 'Enter the question (at least 5 characters).'); if (text.length < 5) ok = false;
      const opts = [0, 1, 2, 3].map(i => f['o' + i].value.trim()); const seen = new Set();
      opts.forEach((o, i) => {
        let msg = ''; if (!o) msg = 'Enter this option.'; else if (seen.has(o.toLowerCase())) msg = 'Options must be different.'; seen.add(o.toLowerCase());
        UI.setErr(f['o' + i], msg); if (msg) ok = false;
      });
      if (!ok) return;
      const correct = +ev.target.querySelector('input[name=correct]:checked').value;
      const fresh = DB.getExam(state.examId);
      if (q) { const t = fresh.questions.find(x => x.id === qid); t.text = text; t.options = opts; t.correct = correct; }
      else fresh.questions.push({ id: DB.newQuestionId(), text, options: opts, correct });
      DB.saveExam(fresh); DB.logActivity(`${q ? 'Edited' : 'Added'} a question in "${fresh.title}"`);
      m.close(); UI.toast(q ? 'Question updated.' : 'Question added.', 'success'); questions();
    });
  }

  /* ---------- students ---------- */
  function students() {
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>Students</h2><p class="muted">Everyone who has registered on the student portal.</p></div></div>
      <div class="card flush"><div class="toolbar">${searchBox('stuSearch', 'Search by name, register number, email or mobile', state.q.students)}</div><div id="box"></div></div>`;
    const draw = () => {
      const q = state.q.students.trim().toLowerCase(), rs = DB.getResults();
      const list = DB.getStudents().filter(s => !q || [s.name, s.regNo, s.email, s.mobile].join(' ').toLowerCase().includes(q));
      $('#box').innerHTML = list.length ? `<div class="table-wrap"><table><thead><tr><th>Student</th><th>Register no.</th><th>Mobile</th><th>Registered</th><th>Exams taken</th><th class="right">Actions</th></tr></thead><tbody>
        ${list.map(s => `<tr><td><strong>${esc(s.name)}</strong><span class="sub">${esc(s.email)}</span></td><td>${esc(s.regNo)}</td><td>${esc(s.mobile)}</td><td>${UI.fmtDate(s.createdAt)}</td><td>${rs.filter(r => r.studentId === s.id).length}</td>
          <td><div class="actions"><button class="btn btn-soft btn-sm" data-act="view-stu" data-id="${s.id}">${icon('eye', 14)} View</button>
          <button class="btn-icon sm danger" title="Delete student" aria-label="Delete student" data-act="del-stu" data-id="${s.id}">${icon('trash', 15)}</button></div></td></tr>`).join('')}</tbody></table></div>`
        : `<div class="empty"><strong>${q ? 'No students match your search' : 'No students registered yet'}</strong>${q ? 'Try a different word.' : 'Students appear here after they register.'}</div>`;
    };
    draw(); hook('stuSearch', 'students', draw);
  }
  function viewStudent(id) {
    const s = DB.getStudent(id); if (!s) return;
    const rs = DB.resultsFor(id);
    const avg = rs.length ? rs.reduce((a, r) => a + r.percentage, 0) / rs.length : 0;
    UI.modal(`<div class="profile-head" style="margin-bottom:18px"><div class="avatar lg">${esc(UI.initials(s.name))}</div><div><h3 style="margin:0">${esc(s.name)}</h3><span class="badge primary">${esc(s.regNo)}</span></div></div>
      <dl class="kv"><dt>Email ID</dt><dd>${esc(s.email)}</dd><dt>Mobile number</dt><dd>${esc(s.mobile)}</dd><dt>Registered</dt><dd>${UI.fmtDateTime(s.createdAt)}</dd><dt>Last login</dt><dd>${s.lastLogin ? UI.fmtDateTime(s.lastLogin) : 'Never'}</dd>
      <dt>Performance</dt><dd>${rs.length} exam${rs.length === 1 ? '' : 's'} · average ${rs.length ? UI.pct(avg) : '—'}</dd></dl>
      <h4 style="margin:22px 0 10px">Exam history</h4>
      ${rs.length ? `<div class="table-wrap"><table style="min-width:520px"><thead><tr><th>Exam</th><th>Date</th><th>Marks</th><th>%</th><th>Status</th></tr></thead><tbody>${rs.map(r => `<tr><td>${esc(r.examTitle)}</td><td>${UI.fmtDate(r.date)}</td><td>${r.marks}/${r.totalMarks}</td><td>${UI.pct(r.percentage)}</td><td>${passBadge(r)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="empty small">This student has not taken any exam yet.</div>'}
      <div class="modal-actions"><button class="btn btn-ghost" data-close>Close</button></div>`, { wide: true });
  }

  /* ---------- results ---------- */
  function resultsTable(list, actions) {
    if (!list.length) return '<div class="empty"><strong>No results found</strong>Results appear here after students submit exams.</div>';
    return `<div class="table-wrap"><table><thead><tr><th>Student</th><th>Register no.</th><th>Exam</th><th>Date</th><th>Marks</th><th>Percentage</th><th>Status</th>${actions ? '<th class="right">Actions</th>' : ''}</tr></thead><tbody>
      ${list.map(r => `<tr><td><strong>${esc(r.studentName)}</strong></td><td>${esc(r.regNo)}</td><td>${esc(r.examTitle)}<span class="sub">${esc(r.subject)}</span></td><td>${UI.fmtDateTime(r.date)}</td>
        <td>${r.marks} / ${r.totalMarks}<span class="sub">${r.correct} correct · ${r.wrong} wrong · ${r.unanswered} skipped</span></td><td><strong>${UI.pct(r.percentage)}</strong></td><td>${passBadge(r)}</td>
        ${actions ? `<td><div class="actions"><button class="btn-icon sm danger" title="Delete result" aria-label="Delete result" data-act="del-res" data-id="${r.id}">${icon('trash', 15)}</button></div></td>` : ''}</tr>`).join('')}</tbody></table></div>`;
  }
  const filteredResults = () => {
    const q = state.q.results.trim().toLowerCase();
    return DB.getResults().filter(r => (state.status === 'all' || (state.status === 'pass') === r.passed) && (!q || (r.studentName + ' ' + r.regNo + ' ' + r.examTitle).toLowerCase().includes(q)))
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  };
  function results() {
    $('#view').innerHTML = `
      <div class="page-head"><div><h2>Student results</h2><p class="muted">Search by student name or register number.</p></div>
        <button class="btn btn-primary" data-act="export">${icon('download')} Export CSV</button></div>
      <div class="card flush"><div class="toolbar">${searchBox('resSearch', 'Search by name, register number or exam', state.q.results)}
        <select class="select" id="statusFilter" aria-label="Filter by status"><option value="all">All results</option><option value="pass">Pass only</option><option value="fail">Fail only</option></select>
        <span class="muted small" id="count"></span></div><div id="box"></div></div>`;
    $('#statusFilter').value = state.status;
    const draw = () => { const l = filteredResults(); $('#box').innerHTML = resultsTable(l, true); $('#count').textContent = `${l.length} result${l.length === 1 ? '' : 's'}`; };
    draw(); hook('resSearch', 'results', draw);
    $('#statusFilter').addEventListener('change', e => { state.status = e.target.value; draw(); });
  }
  function exportCSV() {
    const l = filteredResults(); if (!l.length) return UI.toast('There are no results to export.', 'error');
    const cell = v => { v = String(v == null ? '' : v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
    const head = ['Student Name', 'Register Number', 'Email', 'Exam', 'Subject', 'Date', 'Total Questions', 'Correct', 'Wrong', 'Unanswered', 'Marks', 'Total Marks', 'Percentage', 'Status'];
    const rows = l.map(r => [r.studentName, r.regNo, r.email, r.examTitle, r.subject, new Date(r.date).toLocaleString(), r.total, r.correct, r.wrong, r.unanswered, r.marks, r.totalMarks, r.percentage, r.passed ? 'Pass' : 'Fail']);
    UI.downloadFile(`exam-results-${new Date().toISOString().slice(0, 10)}.csv`, '\ufeff' + [head, ...rows].map(r => r.map(cell).join(',')).join('\r\n'), 'text/csv;charset=utf-8');
    DB.logActivity(`Exported ${l.length} result(s) as CSV`); UI.toast(`Exported ${l.length} result${l.length === 1 ? '' : 's'} to CSV.`, 'success');
  }

  /* ---------- activity + settings ---------- */
  function activity() {
    const a = DB.getActivity();
    $('#view').innerHTML = `<div class="page-head"><div><h2>Admin activity</h2><p class="muted">A log of admin actions and student events.</p></div>
      ${a.length ? `<button class="btn btn-ghost" data-act="clear-log">${icon('trash', 16)} Clear log</button>` : ''}</div>
      <div class="card">${a.length ? `<ul class="feed">${a.map(x => `<li><span class="dotmark"></span><div>${esc(x.text)}<time>${esc(x.actor)} · ${UI.fmtDateTime(x.time)}</time></div></li>`).join('')}</ul>` : '<div class="empty"><strong>No activity recorded</strong>Actions you take will be listed here.</div>'}</div>`;
  }
  function settings() {
    const a = DB.getAdmin();
    $('#view').innerHTML = `<div class="page-head"><div><h2>Settings</h2><p class="muted">Account security and demo data.</p></div></div>
      <div class="grid two">
        <form class="card" id="pwForm" novalidate><h3>Change admin password</h3>
          <div class="field"><label for="a-old">Current password</label><input id="a-old" name="old" type="password" autocomplete="current-password"><span class="err"></span></div>
          <div class="field"><label for="a-new">New password</label><input id="a-new" name="pw" type="password" autocomplete="new-password"><span class="err"></span></div>
          <div class="field"><label for="a-cf">Confirm new password</label><input id="a-cf" name="cf" type="password" autocomplete="new-password"><span class="err"></span></div>
          <button class="btn btn-primary" type="submit">Update password</button></form>
        <div class="stack"><div class="card"><h3>Account</h3><dl class="kv"><dt>Username</dt><dd>${esc(a.username)}</dd><dt>Signed in</dt><dd>${UI.fmtDateTime(a.lastLogin)}</dd><dt>Previous sign-in</dt><dd>${a.previousLogin ? UI.fmtDateTime(a.previousLogin) : '—'}</dd></dl></div>
        <div class="card"><h3>Reset demo data</h3><p class="muted">Deletes every student, exam, question and result you created, then restores the sample data. You will be logged out.</p><button class="btn btn-danger" data-act="reset">Reset all data</button></div></div>
      </div>`;
    $('#pwForm').addEventListener('submit', e => {
      e.preventDefault(); const f = e.target.elements;
      const okNew = f.pw.value.length >= 6; UI.setErr(f.old, f.old.value ? '' : 'Enter your current password.');
      UI.setErr(f.pw, okNew ? '' : 'Use at least 6 characters.'); UI.setErr(f.cf, f.cf.value === f.pw.value ? '' : 'Passwords do not match.');
      if (!f.old.value || !okNew || f.cf.value !== f.pw.value) return;
      const r = DB.changeAdminPassword(f.old.value, f.pw.value); if (!r.ok) return UI.setErr(f.old, r.error);
      UI.toast('Admin password updated.', 'success'); e.target.reset();
    });
  }

  /* ---------- actions (event delegation) ---------- */
  document.addEventListener('click', async ev => {
    const g = ev.target.closest('[data-go]'); if (g) return go(g.dataset.go);
    const b = ev.target.closest('[data-act]'); if (!b) return;
    const id = b.dataset.id, act = b.dataset.act;
    switch (act) {
      case 'new-exam': return examForm();
      case 'edit-exam': return examForm(DB.getExam(id));
      case 'questions': return go('questions', id);
      case 'add-q': return questionForm();
      case 'edit-q': return questionForm(id);
      case 'toggle-pub': {
        const e = DB.getExam(id);
        if (!e.published && !e.questions.length) return UI.toast('Add at least one question before publishing this exam.', 'error');
        e.published = !e.published; DB.saveExam(e);
        DB.logActivity(`${e.published ? 'Published' : 'Unpublished'} exam "${e.title}"`);
        if (e.published) DB.addNote('students', `New exam available: "${e.title}" (${e.subject}).`);
        UI.toast(e.published ? `"${e.title}" is now published. Students can see it.` : `"${e.title}" is now hidden from students.`, 'success');
        return go(state.view, state.examId);
      }
      case 'del-exam': {
        const e = DB.getExam(id);
        if (await UI.confirm({ title: 'Delete this exam?', message: `<b>${esc(e.title)}</b> and its ${e.questions.length} question(s) will be removed. Past student results are kept.`, confirmText: 'Delete exam', danger: true })) { DB.deleteExam(id); UI.toast('Exam deleted.', 'success'); go('exams'); }
        return;
      }
      case 'del-q': {
        if (await UI.confirm({ title: 'Delete this question?', message: 'This cannot be undone.', confirmText: 'Delete question', danger: true })) {
          const e = DB.getExam(state.examId); e.questions = e.questions.filter(q => q.id !== id);
          if (!e.questions.length && e.published) { e.published = false; UI.toast('Exam unpublished because it has no questions left.', 'warn'); }
          DB.saveExam(e); DB.logActivity(`Deleted a question from "${e.title}"`); UI.toast('Question deleted.', 'success'); questions();
        }
        return;
      }
      case 'view-stu': return viewStudent(id);
      case 'del-stu': {
        const s = DB.getStudent(id);
        if (await UI.confirm({ title: 'Delete this student?', message: `<b>${esc(s.name)}</b> (${esc(s.regNo)}) and all of their results will be removed.`, confirmText: 'Delete student', danger: true })) { DB.deleteStudent(id); UI.toast('Student deleted.', 'success'); students(); }
        return;
      }
      case 'del-res': {
        if (await UI.confirm({ title: 'Delete this result?', message: 'The result will be removed from the student\'s history too.', confirmText: 'Delete result', danger: true })) { DB.deleteResult(id); UI.toast('Result deleted.', 'success'); results(); }
        return;
      }
      case 'export': return exportCSV();
      case 'clear-log': if (await UI.confirm({ title: 'Clear the activity log?', message: 'All log entries will be removed.', confirmText: 'Clear log', danger: true })) { DB.clearActivity(); activity(); } return;
      case 'reset':
        if (await UI.confirm({ title: 'Reset all data?', message: 'This wipes all data and restores the sample exams, students and results.', confirmText: 'Reset everything', danger: true })) { DB.resetAll(); location.href = 'login.html'; }
        return;
    }
  });

  shell();
  const h = (location.hash || '#overview').slice(1);
  go(NAV.some(n => n[0] === h) ? h : 'overview');
  setInterval(() => renderBell(), 20000);
  window.addEventListener('storage', () => renderBell());
})();
