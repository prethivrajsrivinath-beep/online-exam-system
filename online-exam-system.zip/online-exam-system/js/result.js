/* Result page */
(function () {
  const me = DB.requireStudent(); if (!me) return;
  const { $, esc, icon } = UI; UI.initTheme();
  const id = new URLSearchParams(location.search).get('id');
  const r = DB.getResults().find(x => x.id === id && x.studentId === me.id);
  if (!r) { $('#app').innerHTML = `<div class="narrow"><div class="card empty"><strong>Result not found</strong><a class="btn btn-primary" href="dashboard.html#results">Back to results</a></div></div>`; return; }
  const flash = sessionStorage.getItem('ex_flash'); sessionStorage.removeItem('ex_flash');

  const stat = (v, l, c) => `<div class="tile"><b ${c ? `style="color:var(--${c})"` : ''}>${v}</b><span>${l}</span></div>`;
  $('#app').innerHTML = `
    <div class="plain-top"><a class="brand" href="dashboard.html"><span class="brand-mark">${icon('check', 20)}</span>ExamDesk</a>
      <button class="btn-icon" data-theme-toggle aria-label="Toggle theme"></button></div>
    <div class="narrow">
      <div class="card">
        <div class="result-hero">
          <div class="ring ${r.passed ? '' : 'fail'}" id="ring" style="--p:0"><div><span><b>${UI.pct(r.percentage)}</b><small>score</small></span></div></div>
          <div style="flex:1;min-width:220px">
            <span class="status-big ${r.passed ? 'pass' : 'fail'}">${icon(r.passed ? 'check' : 'x', 18)} ${r.passed ? 'Pass' : 'Fail'}</span>
            <h2 style="margin-bottom:.2em">${esc(r.examTitle)}</h2>
            <p class="muted" style="margin:0">${esc(r.subject)} · Submitted ${UI.fmtDateTime(r.date)}${r.autoSubmitted ? ' · auto-submitted when time ended' : ''}</p>
            <p class="muted small" style="margin:.4em 0 0">Pass mark: ${r.passPercent}% · Time taken: ${UI.fmtTaken(r.timeTaken)}</p>
          </div>
        </div>
        <div class="info-tiles" style="margin-top:24px">
          ${stat(r.total, 'Total questions')}${stat(r.correct, 'Correct answers', 'good')}${stat(r.wrong, 'Wrong answers', 'bad')}${stat(r.unanswered, 'Unanswered')}
          ${stat(`${r.marks} / ${r.totalMarks}`, 'Total marks')}${stat(UI.pct(r.percentage), 'Percentage')}
        </div>
        <div class="modal-actions no-print" style="justify-content:flex-start;margin-top:8px">
          <a class="btn btn-primary" href="dashboard.html#results">Back to dashboard</a>
          <button class="btn btn-ghost" id="printBtn">Print result</button>
        </div>
      </div>
      ${r.review && r.review.length ? `<div class="card" style="margin-top:18px"><h3>Answer review</h3>
        ${r.review.map((q, i) => `<div class="review-item"><div class="q">${i + 1}. ${esc(q.text)} ${q.chosen === null ? '<span class="badge muted">Unanswered</span>' : q.chosen === q.correct ? '<span class="badge good">Correct</span>' : '<span class="badge bad">Wrong</span>'}</div>
          ${q.options.map((o, j) => `<div class="rev-opt ${j === q.correct ? 'correct' : j === q.chosen ? 'wrong' : ''}"><span>${'ABCD'[j]}.</span><span>${esc(o)}</span>${j === q.correct ? '<em>Correct answer</em>' : j === q.chosen ? '<em>Your answer</em>' : ''}</div>`).join('')}</div>`).join('')}
      </div>` : ''}
    </div>`;
  UI.syncThemeIcons();
  $('#printBtn').onclick = () => window.print();
  requestAnimationFrame(() => setTimeout(() => { $('#ring').style.setProperty('--p', r.percentage); }, 80));
  UI.toast(flash || (r.passed ? 'Exam submitted. Congratulations, you passed!' : 'Exam submitted. Keep practising, you can try again.'), flash ? 'warn' : (r.passed ? 'success' : 'info'), 6000);
})();
