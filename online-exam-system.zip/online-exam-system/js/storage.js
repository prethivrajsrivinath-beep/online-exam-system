/* ==========================================================
   ExamDesk – data layer (LocalStorage)
   Student and admin data live under separate keys / sessions.
   ========================================================== */
const DB = (() => {
  const K = {
    students: 'ex_students',
    exams: 'ex_exams',
    results: 'ex_results',
    notes: 'ex_notifications',
    activity: 'ex_activity',
    admin: 'ex_admin',
    sStudent: 'ex_session_student',
    sAdmin: 'ex_session_admin',
    attempt: 'ex_attempt_',       // + studentId  (in-progress exam, auto-saved answers)
    seeded: 'ex_seeded_v1'
  };

  const read = (k, d) => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } };
  const write = (k, v) => localStorage.setItem(k, JSON.stringify(v));
  const uid = p => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  // Demo-only hash. A real system must hash passwords on a server.
  const hash = s => { let h = 5381; const t = 'examdesk|' + s; for (let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0; return 'h' + (h >>> 0).toString(16) + t.length; };
  const daysAgo = n => new Date(Date.now() - n * 864e5).toISOString();

  /* ---------------- seed data ---------------- */
  function makeExam(id, title, subject, duration, totalMarks, published, qs, extra) {
    const now = new Date().toISOString();
    return Object.assign({
      id, title, subject, duration, totalMarks, passPercent: 40, published, startDate: '',
      instructions: '', shuffleQuestions: true, shuffleOptions: true, createdAt: now, updatedAt: now,
      questions: qs.map((q, i) => ({ id: id + '_q' + (i + 1), text: q[0], options: q[1], correct: q[2] }))
    }, extra || {});
  }

  function seed() {
    if (localStorage.getItem(K.seeded)) return;
    const exams = [
      makeExam('exam_js', 'JavaScript Fundamentals', 'Programming', 10, 20, true, [
        ['Which keyword declares a block-scoped variable that can be reassigned?', ['var', 'let', 'const', 'function'], 1],
        ['What does typeof null return?', ['"null"', '"undefined"', '"object"', '"number"'], 2],
        ['Which array method adds an element to the end of an array?', ['push()', 'pop()', 'shift()', 'unshift()'], 0],
        ['What is the result of 2 + "2" in JavaScript?', ['4', '"22"', 'NaN', 'Error'], 1],
        ['What does the === operator check?', ['Value only', 'Type only', 'Value and type', 'Reference only'], 2],
        ['Which of these is NOT a JavaScript data type?', ['String', 'Boolean', 'Float', 'Symbol'], 2],
        ['Which method converts a JSON string into an object?', ['JSON.parse()', 'JSON.stringify()', 'JSON.object()', 'JSON.decode()'], 0],
        ['Which event fires when a user clicks an element?', ['onchange', 'onclick', 'onhover', 'onpress'], 1]
      ], { instructions: 'This paper covers core JavaScript syntax and behaviour. Each question carries equal marks.' }),
      makeExam('exam_web', 'HTML & CSS Basics', 'Web Development', 8, 12, true, [
        ['What does HTML stand for?', ['HyperText Markup Language', 'HighText Machine Language', 'Hyperlinks and Text Markup Language', 'Home Tool Markup Language'], 0],
        ['Which CSS property changes the text colour?', ['font-color', 'text-color', 'color', 'fg-color'], 2],
        ['Which tag creates a hyperlink?', ['<link>', '<a>', '<href>', '<url>'], 1],
        ['Which CSS layout module is designed for one-dimensional layouts?', ['Float', 'Flexbox', 'Table layout', 'Inline blocks'], 1],
        ['Which element is the semantic choice for main navigation links?', ['<nav>', '<div>', '<span>', '<section>'], 0],
        ['What are CSS media queries mainly used for?', ['Responsive design', 'Database access', 'Server routing', 'Encrypting data'], 0]
      ]),
      makeExam('exam_apt', 'General Aptitude Test', 'Aptitude', 12, 12, true, [
        ['What is 15% of 200?', ['20', '25', '30', '35'], 2],
        ['What comes next in the series 2, 6, 12, 20, ?', ['28', '30', '32', '36'], 1],
        ['A train travels at 60 km/h. How far does it go in 45 minutes?', ['40 km', '45 km', '50 km', '55 km'], 1],
        ['If A=1, B=2, C=3 and so on, what is the sum of the letters in CAB?', ['5', '6', '7', '8'], 1],
        ['What is the average of 10, 20, 30 and 40?', ['20', '25', '30', '35'], 1],
        ['An item bought for 400 is sold for 500. What is the profit percentage?', ['20%', '25%', '30%', '15%'], 1]
      ]),
      makeExam('exam_cs', 'Computer Fundamentals (Draft)', 'Computer Science', 6, 8, false, [
        ['What does CPU stand for?', ['Central Processing Unit', 'Computer Power Unit', 'Central Program Utility', 'Core Processing Update'], 0],
        ['Which of these is an operating system?', ['Chrome', 'Linux', 'Python', 'HTML'], 1],
        ['What is the binary representation of decimal 5?', ['100', '101', '110', '111'], 1],
        ['Which memory is volatile?', ['ROM', 'Hard disk', 'RAM', 'SSD'], 2]
      ], { instructions: 'Draft paper – publish it from the admin panel when the questions are final.' }),
      makeExam('exam_ds', 'Data Structures Mid-Term', 'Computer Science', 10, 8, true, [
        ['Which data structure follows the LIFO principle?', ['Queue', 'Stack', 'Array', 'Graph'], 1],
        ['What is the time complexity of binary search?', ['O(n)', 'O(n log n)', 'O(log n)', 'O(1)'], 2],
        ['Which data structure follows the FIFO principle?', ['Stack', 'Tree', 'Queue', 'Heap'], 2],
        ['Which tree traversal visits the root node first?', ['Inorder', 'Preorder', 'Postorder', 'Level order (reverse)'], 1]
      ], { startDate: new Date(Date.now() + 3 * 864e5).toISOString(), instructions: 'Scheduled paper – it opens automatically on the date shown.' })
    ];
    write(K.exams, exams);

    const students = [
      { id: 'stu_demo1', name: 'Aarav Kumar', email: 'aarav@example.com', mobile: '9876543210', regNo: 'STU2024001', password: hash('student123'), createdAt: daysAgo(14), lastLogin: null },
      { id: 'stu_demo2', name: 'Meera Nair', email: 'meera@example.com', mobile: '9123456780', regNo: 'STU2024002', password: hash('student123'), createdAt: daysAgo(9), lastLogin: null }
    ];
    write(K.students, students);

    const res = (id, st, ex, c, w, u, marks, pct, passed, ago, secs) => ({
      id, studentId: st.id, studentName: st.name, regNo: st.regNo, email: st.email, examId: ex.id, examTitle: ex.title, subject: ex.subject,
      total: ex.questions.length, correct: c, wrong: w, unanswered: u, marks, totalMarks: ex.totalMarks, percentage: pct, passed,
      passPercent: ex.passPercent, date: daysAgo(ago), timeTaken: secs, autoSubmitted: false, review: []
    });
    write(K.results, [
      res('res_seed1', students[0], exams[0], 6, 1, 1, 15, 75, true, 6, 412),
      res('res_seed2', students[0], exams[1], 4, 2, 0, 8, 66.67, true, 2, 301),
      res('res_seed3', students[1], exams[2], 2, 3, 1, 4, 33.33, false, 3, 560)
    ]);

    write(K.admin, { username: 'admin', password: hash('admin123'), lastLogin: null, previousLogin: null });
    write(K.notes, [
      { id: uid('n_'), to: 'students', text: 'Welcome to ExamDesk! Published exams appear under "Exams".', time: daysAgo(1), readBy: [] },
      { id: uid('n_'), to: 'admin', text: 'Demo data loaded: 5 exam papers, 2 students and 3 results.', time: daysAgo(0), readBy: [] }
    ]);
    write(K.activity, [
      { id: uid('a_'), text: 'Demo data created', actor: 'System', time: new Date().toISOString() }
    ]);
    localStorage.setItem(K.seeded, '1');
  }

  /* ---------------- activity + notifications ---------------- */
  const getActivity = () => read(K.activity, []);
  function logActivity(text, actor) {
    const list = getActivity();
    list.unshift({ id: uid('a_'), text, actor: actor || 'Admin', time: new Date().toISOString() });
    write(K.activity, list.slice(0, 200));
  }
  const clearActivity = () => write(K.activity, []);

  const allNotes = () => read(K.notes, []);
  function addNote(to, text) {
    const list = allNotes();
    list.unshift({ id: uid('n_'), to, text, time: new Date().toISOString(), readBy: [] });
    write(K.notes, list.slice(0, 200));
  }
  const getNotes = viewer => allNotes().filter(n => n.to === viewer || (viewer !== 'admin' && n.to === 'students'));
  function markNotesRead(viewer) {
    const list = allNotes();
    list.forEach(n => { if ((n.to === viewer || (viewer !== 'admin' && n.to === 'students')) && !n.readBy.includes(viewer)) n.readBy.push(viewer); });
    write(K.notes, list);
  }

  /* ---------------- students ---------------- */
  const getStudents = () => read(K.students, []);
  const saveStudents = l => write(K.students, l);
  const getStudent = id => getStudents().find(s => s.id === id) || null;

  function registerStudent(d) {
    const list = getStudents();
    const email = d.email.trim().toLowerCase(), regNo = d.regNo.trim().toUpperCase();
    if (list.some(s => s.email === email)) return { ok: false, field: 'email', error: 'This email is already registered. Try logging in instead.' };
    if (list.some(s => s.regNo === regNo)) return { ok: false, field: 'regNo', error: 'This register number is already registered.' };
    const s = { id: uid('stu_'), name: d.name.trim(), email, mobile: d.mobile.trim(), regNo, password: hash(d.password), createdAt: new Date().toISOString(), lastLogin: null };
    list.push(s); saveStudents(list);
    logActivity(`New student registered: ${s.name} (${s.regNo})`, 'System');
    addNote('admin', `New student registered: ${s.name} (${s.regNo}).`);
    return { ok: true, student: s };
  }
  function loginStudent(idf, pw) {
    const key = idf.trim().toLowerCase();
    const list = getStudents();
    const s = list.find(x => x.email === key || x.regNo.toLowerCase() === key);
    if (!s) return { ok: false, error: 'No student found with that email or register number.' };
    if (s.password !== hash(pw)) return { ok: false, error: 'Incorrect password. Please try again.' };
    s.lastLogin = new Date().toISOString(); saveStudents(list);
    write(K.sStudent, { id: s.id, at: Date.now() });
    return { ok: true, student: s };
  }
  function currentStudent() {
    const ses = read(K.sStudent, null);
    return ses ? getStudent(ses.id) : null;
  }
  function requireStudent() {
    const s = currentStudent();
    if (!s) { localStorage.removeItem(K.sStudent); location.replace('login.html'); return null; }
    return s;
  }
  const logoutStudent = () => localStorage.removeItem(K.sStudent);
  function updateStudent(id, patch) {
    const list = getStudents(); const s = list.find(x => x.id === id);
    if (!s) return null; Object.assign(s, patch); saveStudents(list); return s;
  }
  function deleteStudent(id) {
    const s = getStudent(id);
    saveStudents(getStudents().filter(x => x.id !== id));
    write(K.results, getResults().filter(r => r.studentId !== id));
    localStorage.removeItem(K.attempt + id);
    if (s) logActivity(`Deleted student ${s.name} (${s.regNo}) and their results`);
  }

  /* ---------------- exams ---------------- */
  const getExams = () => read(K.exams, []);
  const getExam = id => getExams().find(e => e.id === id) || null;
  function saveExam(exam) {
    const list = getExams(); exam.updatedAt = new Date().toISOString();
    const i = list.findIndex(e => e.id === exam.id);
    if (i >= 0) list[i] = exam; else list.push(exam);
    write(K.exams, list); return exam;
  }
  function deleteExam(id) {
    const e = getExam(id);
    write(K.exams, getExams().filter(x => x.id !== id));
    if (e) logActivity(`Deleted exam "${e.title}"`);
  }
  const newExamId = () => uid('exam_');
  const newQuestionId = () => uid('q_');
  function examPhase(e) {
    if (!e.published) return 'draft';
    if (e.startDate && new Date(e.startDate) > new Date()) return 'upcoming';
    return 'open';
  }

  /* ---------------- results ---------------- */
  const getResults = () => read(K.results, []);
  const resultsFor = sid => getResults().filter(r => r.studentId === sid).sort((a, b) => new Date(b.date) - new Date(a.date));
  function addResult(r) { const l = getResults(); l.push(r); write(K.results, l); return r; }
  function deleteResult(id) {
    const r = getResults().find(x => x.id === id);
    write(K.results, getResults().filter(x => x.id !== id));
    if (r) logActivity(`Deleted result: ${r.studentName} – ${r.examTitle}`);
  }
  const newResultId = () => uid('res_');

  /* ---------------- in-progress attempt (auto-save) ---------------- */
  const getAttempt = sid => read(K.attempt + sid, null);
  const saveAttempt = (sid, a) => write(K.attempt + sid, a);
  const clearAttempt = sid => localStorage.removeItem(K.attempt + sid);

  /* ---------------- admin ---------------- */
  const getAdmin = () => read(K.admin, null);
  function loginAdmin(username, pw) {
    const a = getAdmin();
    if (!a || a.username.toLowerCase() !== username.trim().toLowerCase() || a.password !== hash(pw))
      return { ok: false, error: 'Wrong username or password.' };
    a.previousLogin = a.lastLogin; a.lastLogin = new Date().toISOString(); write(K.admin, a);
    write(K.sAdmin, { at: Date.now() });
    logActivity('Admin signed in');
    return { ok: true };
  }
  function currentAdmin() { return read(K.sAdmin, null) ? getAdmin() : null; }
  function requireAdmin() {
    const a = currentAdmin();
    if (!a) { localStorage.removeItem(K.sAdmin); location.replace('login.html'); return null; }
    return a;
  }
  const logoutAdmin = () => { logActivity('Admin signed out'); localStorage.removeItem(K.sAdmin); };
  function changeAdminPassword(oldPw, newPw) {
    const a = getAdmin();
    if (a.password !== hash(oldPw)) return { ok: false, error: 'Current password is incorrect.' };
    a.password = hash(newPw); write(K.admin, a); logActivity('Admin password changed'); return { ok: true };
  }
  function changeStudentPassword(id, oldPw, newPw) {
    const s = getStudent(id);
    if (!s || s.password !== hash(oldPw)) return { ok: false, error: 'Current password is incorrect.' };
    updateStudent(id, { password: hash(newPw) }); return { ok: true };
  }

  function resetAll() {
    Object.keys(localStorage).filter(k => k.startsWith('ex_') && k !== 'ex_theme').forEach(k => localStorage.removeItem(k));
    seed();
  }
  function init() { seed(); }

  return {
    init, resetAll, hash, examPhase,
    getStudents, getStudent, registerStudent, loginStudent, currentStudent, requireStudent, logoutStudent, updateStudent, deleteStudent, changeStudentPassword,
    getExams, getExam, saveExam, deleteExam, newExamId, newQuestionId,
    getResults, resultsFor, addResult, deleteResult, newResultId,
    getAttempt, saveAttempt, clearAttempt,
    getAdmin, loginAdmin, currentAdmin, requireAdmin, logoutAdmin, changeAdminPassword,
    getActivity, logActivity, clearActivity, addNote, getNotes, markNotesRead
  };
})();
DB.init();
