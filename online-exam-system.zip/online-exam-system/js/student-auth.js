/* Student login / register page */
(function () {
  const { $, setErr } = UI;
  UI.initTheme(); UI.bindPasswordToggles(); UI.renderOMR($('#omr'));
  $('#mark').innerHTML = UI.icon('check', 20);
  if (DB.currentStudent()) { location.replace('dashboard.html'); return; }

  const loginForm = $('#loginForm'), regForm = $('#registerForm');
  function show(which) {
    const login = which === 'login';
    loginForm.hidden = !login; regForm.hidden = login;
    $('#tabLogin').classList.toggle('active', login); $('#tabRegister').classList.toggle('active', !login);
    (login ? $('#l-id') : $('#r-name')).focus();
  }
  $('#tabLogin').onclick = () => show('login');
  $('#tabRegister').onclick = () => show('register');

  const rules = {
    required: v => v.trim() ? true : 'This field is required.',
    name: v => /^[A-Za-z][A-Za-z .'-]{2,49}$/.test(v.trim()) || 'Enter your full name (letters only, at least 3 characters).',
    email: v => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) || 'Enter a valid email address, like name@example.com.',
    mobile: v => /^[6-9]\d{9}$/.test(v.trim()) || 'Enter a 10-digit mobile number starting with 6, 7, 8 or 9.',
    regNo: v => /^[A-Za-z0-9\-\/]{4,20}$/.test(v.trim()) || 'Use 4–20 letters, numbers, "-" or "/".',
    password: v => (v.length >= 6 && /[A-Za-z]/.test(v) && /\d/.test(v)) || 'Use at least 6 characters with a letter and a number.',
    confirm: (v, f) => v === f.elements.password.value || 'Passwords do not match.'
  };
  function checkField(inp, form) {
    const r = rules[inp.dataset.rule]; if (!r) return true;
    const res = r(inp.value, form); setErr(inp, res === true ? '' : res); return res === true;
  }
  function checkForm(form) {
    let ok = true, first = null;
    form.querySelectorAll('[data-rule]').forEach(i => { if (!checkField(i, form)) { ok = false; first = first || i; } });
    if (first) first.focus(); return ok;
  }
  [loginForm, regForm].forEach(f => {
    f.querySelectorAll('[data-rule]').forEach(i => {
      i.addEventListener('blur', () => { if (i.value || i.dataset.touched) { i.dataset.touched = 1; checkField(i, f); } });
      i.addEventListener('input', () => { if (i.dataset.touched) checkField(i, f); if (i.name === 'password' && f.elements.confirm.dataset.touched) checkField(f.elements.confirm, f); });
    });
  });
  const banner = (el, msg) => { el.textContent = msg || ''; el.hidden = !msg; };

  loginForm.addEventListener('submit', e => {
    e.preventDefault(); banner($('#loginError')); banner($('#loginOk'));
    if (!checkForm(loginForm)) return;
    const r = DB.loginStudent(loginForm.elements.identifier.value, loginForm.elements.password.value);
    if (!r.ok) return banner($('#loginError'), r.error);
    UI.toast('Login successful. Redirecting to your dashboard…', 'success', 1500);
    setTimeout(() => location.href = 'dashboard.html', 600);
  });

  regForm.addEventListener('submit', e => {
    e.preventDefault(); banner($('#regError'));
    if (!checkForm(regForm)) return;
    const f = regForm.elements;
    const r = DB.registerStudent({ name: f.name.value, email: f.email.value, mobile: f.mobile.value, regNo: f.regNo.value, password: f.password.value });
    if (!r.ok) { if (r.field) setErr(f[r.field], r.error); return banner($('#regError'), r.error); }
    UI.toast('Registration complete. You can log in now.', 'success');
    regForm.reset(); regForm.querySelectorAll('[data-touched]').forEach(i => delete i.dataset.touched);
    show('login');
    loginForm.elements.identifier.value = r.student.regNo;
    banner($('#loginOk'), 'Account created. Enter your password to log in.');
    loginForm.elements.password.focus();
  });

  $('#fillDemo').onclick = () => { loginForm.elements.identifier.value = 'STU2024001'; loginForm.elements.password.value = 'student123'; banner($('#loginError')); };
})();
