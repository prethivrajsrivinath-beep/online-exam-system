/* ==========================================================
   ExamDesk – shared UI helpers
   ========================================================== */
const UI = (() => {
  const ICONS = {
    home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    book: '<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    activity: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    settings: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    sun: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
    moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
    menu: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4z"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
    eye: '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    help: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    grid: '<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
    flag: '<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
    back: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    award: '<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>',
    list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>'
  };
  const icon = (n, s = 18) => `<svg class="ic" width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n] || ''}</svg>`;
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => [...(r || document).querySelectorAll(s)];

  /* ---------- formatting ---------- */
  const fmtDate = iso => iso ? new Date(iso).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' }) : '—';
  const fmtDateTime = iso => iso ? new Date(iso).toLocaleString(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }) : '—';
  const pad = n => String(n).padStart(2, '0');
  const fmtClock = sec => { sec = Math.max(0, Math.floor(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60; return (h ? pad(h) + ':' : '') + pad(m) + ':' + pad(s); };
  const fmtTaken = sec => { sec = Math.round(sec || 0); const m = Math.floor(sec / 60), s = sec % 60; return m ? `${m}m ${pad(s)}s` : `${s}s`; };
  const timeAgo = iso => {
    const d = (Date.now() - new Date(iso)) / 1000;
    if (d < 60) return 'just now'; if (d < 3600) return Math.floor(d / 60) + ' min ago';
    if (d < 86400) return Math.floor(d / 3600) + ' hr ago'; if (d < 604800) return Math.floor(d / 86400) + ' days ago';
    return fmtDate(iso);
  };
  const initials = n => (n || '?').trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  const pct = n => (Math.round(n * 100) / 100) + '%';
  const shuffle = a => { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };

  /* ---------- toast ---------- */
  function toast(msg, type = 'info', ms = 4000) {
    let box = $('.toasts');
    if (!box) { box = document.createElement('div'); box.className = 'toasts'; box.setAttribute('aria-live', 'polite'); document.body.appendChild(box); }
    const t = document.createElement('div'); t.className = 'toast ' + type;
    t.innerHTML = `<span class="toast-ic">${icon(type === 'success' ? 'check' : type === 'error' ? 'x' : type === 'warn' ? 'flag' : 'bell', 16)}</span><span>${esc(msg)}</span>`;
    box.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 320); }, ms);
  }

  /* ---------- modal + confirm ---------- */
  function modal(html, opts) {
    opts = opts || {};
    const ov = document.createElement('div'); ov.className = 'overlay';
    ov.innerHTML = `<div class="modal${opts.wide ? ' wide' : ''}" role="dialog" aria-modal="true">${html}</div>`;
    document.body.appendChild(ov); document.body.classList.add('no-scroll');
    let closed = false;
    const key = e => { if (e.key === 'Escape' && ov === $$('.overlay').pop() && !opts.persistent) close(); };
    function close() {
      if (closed) return; closed = true; ov.remove(); document.removeEventListener('keydown', key);
      if (!$('.overlay')) document.body.classList.remove('no-scroll');
      if (opts.onClose) opts.onClose();
    }
    document.addEventListener('keydown', key);
    if (!opts.persistent) ov.addEventListener('mousedown', e => { if (e.target === ov) close(); });
    $$('[data-close]', ov).forEach(b => b.addEventListener('click', close));
    const f = $('input:not([type=radio]):not([type=checkbox]),textarea,select', ov) || $('.btn-primary,.btn-danger', ov);
    if (f) f.focus();
    return { el: ov.firstElementChild, overlay: ov, close };
  }
  function confirm(o) {
    return new Promise(res => {
      let done = false;
      const m = modal(`<h3>${esc(o.title || 'Are you sure?')}</h3><div class="muted">${o.message || ''}</div>
        <div class="modal-actions"><button class="btn btn-ghost" data-close>${esc(o.cancelText || 'Cancel')}</button>
        <button class="btn ${o.danger ? 'btn-danger' : 'btn-primary'}" data-ok>${esc(o.confirmText || 'Confirm')}</button></div>`,
        { onClose: () => { if (!done) { done = true; res(false); } } });
      $('[data-ok]', m.el).addEventListener('click', () => { done = true; m.close(); res(true); });
    });
  }

  /* ---------- theme ---------- */
  function applyTheme(t) {
    document.documentElement.dataset.theme = t; localStorage.setItem('ex_theme', t);
    syncThemeIcons();
  }
  function syncThemeIcons() {
    const dark = document.documentElement.dataset.theme === 'dark';
    $$('[data-theme-toggle]').forEach(b => { b.innerHTML = icon(dark ? 'sun' : 'moon') + '<span class="sr">Switch to ' + (dark ? 'light' : 'dark') + ' mode</span>'; b.title = 'Switch to ' + (dark ? 'light' : 'dark') + ' mode'; });
  }
  function initTheme() {
    const saved = localStorage.getItem('ex_theme') || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.dataset.theme = saved; syncThemeIcons();
    document.addEventListener('click', e => {
      if (e.target.closest('[data-theme-toggle]')) applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
    });
  }

  /* ---------- notifications bell ---------- */
  function initNotifications(viewer) {
    const btn = $('#bell'), panel = $('#notifPanel'), dot = $('#bellDot');
    if (!btn) return () => {};
    const render = () => {
      const list = DB.getNotes(viewer);
      const unread = list.filter(n => !n.readBy.includes(viewer)).length;
      dot.textContent = unread > 9 ? '9+' : unread; dot.hidden = !unread;
      panel.innerHTML = `<div class="notif-head"><strong>Notifications</strong><button class="link" data-mark>Mark all read</button></div>
        <div class="notif-list">${list.length ? list.slice(0, 20).map(n => `<div class="notif-item ${n.readBy.includes(viewer) ? '' : 'unread'}">${esc(n.text)}<time>${timeAgo(n.time)}</time></div>`).join('') : '<div class="empty small">You are all caught up.</div>'}</div>`;
    };
    btn.addEventListener('click', e => { e.stopPropagation(); panel.hidden = !panel.hidden; if (!panel.hidden) render(); });
    document.addEventListener('click', e => { if (!panel.contains(e.target) && !btn.contains(e.target)) panel.hidden = true; });
    panel.addEventListener('click', e => { if (e.target.closest('[data-mark]')) { DB.markNotesRead(viewer); render(); } });
    render(); return render;
  }

  /* ---------- charts ---------- */
  function bars(items, pass) {
    pass = pass == null ? 40 : pass;
    if (!items.length) return '<div class="empty small">No data yet.</div>';
    return `<div class="bars">${items.map(i => `<div class="bar-row"><span class="bar-label" title="${esc(i.label)}">${esc(i.label)}</span>
      <div class="bar-track"><div class="bar-fill ${i.value >= pass ? 'good' : 'bad'}" style="width:${Math.max(2, Math.min(100, i.value))}%"></div></div>
      <span class="bar-val">${esc(i.text != null ? i.text : Math.round(i.value) + '%')}</span></div>`).join('')}</div>`;
  }
  function trend(results) {
    if (!results.length) return '<div class="empty small">Your score trend will show up after your first exam.</div>';
    const list = results.slice(0, 8).reverse();
    return `<div class="vcols">${list.map(r => `<div class="vcol"><div class="vbar ${r.passed ? '' : 'bad'}" style="height:${Math.max(3, r.percentage)}%" title="${esc(r.examTitle)}: ${r.percentage}%"><span>${Math.round(r.percentage)}%</span></div></div>`).join('')}</div>
      <div class="vlabels">${list.map(r => `<span title="${esc(r.examTitle)}">${esc(r.examTitle.split(' ')[0])}</span>`).join('')}</div>`;
  }

  /* ---------- misc ---------- */
  function bindPasswordToggles(root) {
    $$('[data-toggle-pw]', root).forEach(b => {
      if (b._bound) return; b._bound = true;
      b.addEventListener('click', () => {
        const i = b.parentElement.querySelector('input'); const show = i.type === 'password';
        i.type = show ? 'text' : 'password'; b.textContent = show ? 'Hide' : 'Show';
      });
    });
  }
  function renderOMR(el) {
    if (!el) return; const filled = [1, 3, 0, 2, 1, 3, 2];
    el.innerHTML = filled.map((f, i) => `<span class="q">${i + 1}</span>` + [0, 1, 2, 3].map(j => `<span class="b${j === f ? ' f' : ''}" style="--d:${(0.5 + i * 0.4).toFixed(2)}s"></span>`).join('')).join('');
  }
  function setErr(input, msg) {
    const f = input.closest('.field'); if (!f) return;
    f.classList.toggle('invalid', !!msg); const e = $('.err', f); if (e) e.textContent = msg || '';
  }
  function downloadFile(name, content, mime) {
    const blob = new Blob([content], { type: mime || 'text/plain' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 500);
  }
  const debounce = (fn, ms = 150) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  return { icon, esc, $, $$, fmtDate, fmtDateTime, fmtClock, fmtTaken, timeAgo, initials, pct, shuffle, toast, modal, confirm, initTheme, syncThemeIcons, applyTheme, initNotifications, bars, trend, bindPasswordToggles, renderOMR, setErr, downloadFile, debounce };
})();
