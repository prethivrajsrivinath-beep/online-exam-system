/* Online exam page */
(function () {
  const me = DB.requireStudent(); if (!me) return;
  const { $, $$, esc, icon } = UI; UI.initTheme();
  const examId = new URLSearchParams(location.search).get('exam');

  /* ---------- load or create the attempt ---------- */
  let attempt = DB.getAttempt(me.id);
  if (attempt && attempt.examId !== examId) { location.replace('exam.html?exam=' + attempt.examId); return; }
  if (!attempt) {
    const ex = DB.getExam(examId);
    const back = msg => { sessionStorage.setItem('ex_flash', msg); location.replace('dashboard.html#exams'); };
    if (!ex || DB.examPhase(ex) !== 'open' || !ex.questions.length) return back('That exam is not available.');
    if (!sessionStorage.getItem('ex_ack_' + me.id + '_' + ex.id)) { location.replace('instructions.html?exam=' + ex.id); return; }
    const qs = ex.shuffleQuestions ? UI.shuffle(ex.questions) : ex.questions.slice();
    const now = Date.now();
    attempt = {
      examId: ex.id, startedAt: now, endsAt: now + ex.duration * 60000,
      exam: { id: ex.id, title: ex.title, subject: ex.subject, duration: ex.duration, totalMarks: ex.totalMarks, passPercent: ex.passPercent, questions: ex.questions },
      order: qs.map(q => ({ id: q.id, opts: ex.shuffleOptions ? UI.shuffle([0, 1, 2, 3]) : [0, 1, 2, 3] })),
      answers: {}, marked: {}, current: 0, warned: false
    };
    DB.saveAttempt(me.id, attempt);
    DB.logActivity(`${me.name} started "${ex.title}"`, 'Student');
    DB.addNote('admin', `${me.name} started "${ex.title}".`);
  }
  const ex = attempt.exam, total = ex.questions.length;
  const qById = {}; ex.questions.forEach(q => qById[q.id] = q);
  const save = () => DB.saveAttempt(me.id, attempt);
  let allowLeave = false, submitting = false;

  /* ---------- layout ---------- */
  $('#app').innerHTML = `
    <header class="exam-head">
      <div class="exam-head-row">
        <div><h1>${esc(ex.title)}</h1><div class="sub"><span class="badge primary">${esc(ex.subject)}</span><span class="badge muted">${total} questions</span><span class="badge muted">${ex.totalMarks} marks</span></div></div>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <div class="timer" id="timer" role="timer" aria-live="off">${icon('clock', 20)}<span id="clock">--:--</span></div>
          <button class="btn-icon" data-theme-toggle aria-label="Toggle theme"></button>
          <button class="btn btn-primary" id="submitTop">Submit exam</button>
        </div>
      </div>
      <div class="progress" aria-hidden="true"><i id="bar" style="width:0"></i></div>
      <div class="progress-text"><span id="progText"></span><span id="savedTxt" class="saved">Answer saved</span></div>
    </header>
    <div class="exam-layout">
      <section class="card q-card" id="qCard"></section>
      <aside class="card palette">
        <h4>Question navigation</h4>
        <div class="pal-grid" id="pal"></div>
        <div class="legend"><span><i class="c"></i>Current</span><span><i class="a"></i>Answered</span><span><i></i>Unanswered</span><span><i class="m"></i>Marked</span></div>
        <p class="muted small" style="margin:14px 0 0">Shortcuts: ← → to move, 1–4 or A–D to answer.</p>
      </aside>
    </div>`;
  UI.syncThemeIcons();

  function renderQuestion() {
    const i = attempt.current, o = attempt.order[i], q = qById[o.id];
    const chosen = attempt.answers[q.id];
    $('#qCard').innerHTML = `
      <div class="q-meta"><span class="badge primary">Question ${i + 1} of ${total}</span>
        <button class="btn btn-ghost btn-sm" id="markBtn">${icon('flag', 14)} ${attempt.marked[q.id] ? 'Unmark review' : 'Mark for review'}</button></div>
      <h2 class="q-title">${esc(q.text)}</h2>
      <div class="options" role="radiogroup" aria-label="Answer options">
        ${o.opts.map((orig, pos) => `<label class="option ${chosen === orig ? 'selected' : ''}">
          <input type="radio" name="opt" value="${orig}" ${chosen === orig ? 'checked' : ''}><span class="letter">${'ABCD'[pos]}</span><span>${esc(q.options[orig])}</span></label>`).join('')}
      </div>
      <div class="q-nav">
        <div class="grp"><button class="btn btn-ghost" id="prevBtn" ${i === 0 ? 'disabled' : ''}>Previous</button>
          <button class="btn btn-ghost" id="clearBtn" ${chosen === undefined ? 'disabled' : ''}>Clear answer</button></div>
        <div class="grp">${i < total - 1 ? '<button class="btn btn-primary" id="nextBtn">Next</button>' : '<button class="btn btn-primary" id="finishBtn">Review & submit</button>'}</div>
      </div>`;
    $$('input[name=opt]', $('#qCard')).forEach(r => r.addEventListener('change', () => select(q.id, +r.value)));
    $('#prevBtn').onclick = () => jump(i - 1);
    $('#clearBtn').onclick = () => { delete attempt.answers[q.id]; save(); renderQuestion(); renderPalette(); renderProgress(); };
    $('#markBtn').onclick = () => { attempt.marked[q.id] = !attempt.marked[q.id]; if (!attempt.marked[q.id]) delete attempt.marked[q.id]; save(); renderQuestion(); renderPalette(); };
    const nb = $('#nextBtn'); if (nb) nb.onclick = () => jump(i + 1);
    const fb = $('#finishBtn'); if (fb) fb.onclick = askSubmit;
  }
  function renderPalette() {
    $('#pal').innerHTML = attempt.order.map((o, i) => {
      const cls = ['pal-btn'];
      if (attempt.answers[o.id] !== undefined) cls.push('answered');
      if (attempt.marked[o.id]) cls.push('marked');
      if (i === attempt.current) cls.push('current');
      return `<button class="${cls.join(' ')}" data-i="${i}" aria-label="Question ${i + 1}${attempt.answers[o.id] !== undefined ? ', answered' : ''}">${i + 1}</button>`;
    }).join('');
  }
  const answeredCount = () => attempt.order.filter(o => attempt.answers[o.id] !== undefined).length;
  function renderProgress() {
    const a = answeredCount();
    $('#bar').style.width = (a / total * 100) + '%';
    $('#progText').textContent = `${a} of ${total} answered`;
  }
  function jump(i) { attempt.current = Math.max(0, Math.min(total - 1, i)); save(); renderQuestion(); renderPalette(); }
  let savedT;
  function select(qid, val) {
    attempt.answers[qid] = val; save(); renderQuestion(); renderPalette(); renderProgress();
    const s = $('#savedTxt'); s.classList.add('show'); clearTimeout(savedT); savedT = setTimeout(() => s.classList.remove('show'), 1200);
  }
  $('#pal').addEventListener('click', e => { const b = e.target.closest('[data-i]'); if (b) jump(+b.dataset.i); });

  /* ---------- timer ---------- */
  function tick() {
    const rem = Math.max(0, Math.round((attempt.endsAt - Date.now()) / 1000));
    $('#clock').textContent = UI.fmtClock(rem);
    const t = $('#timer'); t.classList.toggle('low', rem <= 300 && rem > 60); t.classList.toggle('critical', rem <= 60);
    if (rem <= 300 && rem > 0 && !attempt.warned && ex.duration > 5) {
      attempt.warned = true; save();
      UI.toast('Only 5 minutes remain. The exam will be submitted automatically when time is up.', 'warn', 8000);
    }
    if (rem <= 0) { clearInterval(timerId); finalize(true); }
  }
  const timerId = setInterval(tick, 1000);

  /* ---------- submit ---------- */
  function askSubmit() {
    if (submitting) return;
    const a = answeredCount(), un = total - a, mk = Object.keys(attempt.marked).length;
    const m = UI.modal(`<h3>Submit your exam?</h3>
      <p class="muted">Once you submit, you can't change your answers.</p>
      <ul class="summary-list"><li><b>${a}</b><span>Answered</span></li><li><b>${un}</b><span>Unanswered</span></li><li><b>${mk}</b><span>Marked</span></li></ul>
      ${un ? `<div class="alert error" style="margin:14px 0 0">You have ${un} unanswered question${un > 1 ? 's' : ''}. They will score zero.</div>` : ''}
      <div class="modal-actions"><button class="btn btn-ghost" data-close>Keep working</button><button class="btn btn-primary" id="okSubmit">Yes, submit now</button></div>`);
    $('#okSubmit', m.el).onclick = () => { m.close(); finalize(false); };
  }
  $('#submitTop').onclick = askSubmit;

  function finalize(auto) {
    if (submitting) return; submitting = true; clearInterval(timerId);
    $$('.overlay').forEach(o => o.remove()); document.body.classList.remove('no-scroll');
    const per = ex.totalMarks / total;
    let correct = 0, wrong = 0, unanswered = 0;
    const review = attempt.order.map(o => {
      const q = qById[o.id], ch = attempt.answers[q.id];
      if (ch === undefined) unanswered++; else if (ch === q.correct) correct++; else wrong++;
      return { text: q.text, options: q.options, correct: q.correct, chosen: ch === undefined ? null : ch };
    });
    const marks = Math.round(correct * per * 100) / 100;
    const percentage = Math.round(correct / total * 10000) / 100;
    const spent = Math.min(ex.duration * 60, Math.round((Date.now() - attempt.startedAt) / 1000));
    const r = {
      id: DB.newResultId(), studentId: me.id, studentName: me.name, regNo: me.regNo, email: me.email,
      examId: ex.id, examTitle: ex.title, subject: ex.subject, total, correct, wrong, unanswered,
      marks, totalMarks: ex.totalMarks, percentage, passPercent: ex.passPercent, passed: percentage >= ex.passPercent,
      date: new Date().toISOString(), timeTaken: spent, autoSubmitted: !!auto, review
    };
    DB.addResult(r); DB.clearAttempt(me.id);
    DB.logActivity(`${me.name} submitted "${ex.title}" – ${percentage}% (${r.passed ? 'Pass' : 'Fail'})${auto ? ' [auto-submitted]' : ''}`, 'Student');
    DB.addNote('admin', `${me.name} completed "${ex.title}" with ${percentage}%.`);
    DB.addNote(me.id, `Your result for "${ex.title}" is ready: ${percentage}% (${r.passed ? 'Pass' : 'Fail'}).`);
    allowLeave = true;
    if (auto) sessionStorage.setItem('ex_flash', 'Time is up. Your exam was submitted automatically.');
    location.replace('result.html?id=' + r.id);
  }

  /* ---------- protect against accidental leave / refresh ---------- */
  window.addEventListener('beforeunload', e => { if (!allowLeave) { e.preventDefault(); e.returnValue = ''; } });
  history.pushState(null, '', location.href);
  window.addEventListener('popstate', () => { history.pushState(null, '', location.href); UI.toast('Leaving is disabled during the exam. Use Submit exam when you are done.', 'warn'); });
  document.addEventListener('keydown', e => {
    if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'r')) { e.preventDefault(); UI.toast('Refresh is disabled during the exam. Your answers are saved automatically.', 'warn'); return; }
    if ($('.overlay')) return;
    const o = attempt.order[attempt.current];
    if (e.key === 'ArrowRight') { e.preventDefault(); jump(attempt.current + 1); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); jump(attempt.current - 1); }
    else if (/^[1-4]$/.test(e.key) || /^[a-dA-D]$/.test(e.key)) {
      const pos = /^\d$/.test(e.key) ? +e.key - 1 : 'abcd'.indexOf(e.key.toLowerCase());
      select(o.id, o.opts[pos]);
    }
  });

  renderQuestion(); renderPalette(); renderProgress(); tick();
})();
